"use client";

import Map from "@/components/Map";

export default function Home() {
  return (
    <div className="flex h-screen w-full">
      {/* Lado esquerdo - Mapa */}
      <div className="w-3/4 h-full">
        <Map />
      </div>

      {/* Lado direito - Lista */}
      <div className="w-1/4 h-full overflow-y-scroll bg-black p-4 text-sm">
        {[...Array(10)].map((_, i) => (
          <div key={i} className="border-b border-white/10 pb-4 mb-4">
            <div className="text-green-400 font-semibold">
              ● Divina Beleza Studio
            </div>
            <div className="text-white text-sm">
              R. Koesa, 361, Sala 4 - Kobrasol, São José
            </div>
            <div className="text-green-400">Aberto agora</div>
            <div className="text-white/60 text-xs">
              Disponibilidade de estoque*
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
